kubeadm join 10.0.0.10:6443 --token 0s6dei.3nv1q4xkkv8g98qc --discovery-token-ca-cert-hash sha256:5a7d70a8498795c680b2fe3d7840585ac74b0451769f4781bc4298de4c9b23f8 
